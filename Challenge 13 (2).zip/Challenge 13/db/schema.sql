
DROP DATABASE IF EXISTS ecommerce_db;

CREATE DATABASE ecommerce_db;