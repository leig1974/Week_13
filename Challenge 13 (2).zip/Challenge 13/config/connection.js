require('dotenv').config();

const Sequelize = require('sequelize');

// // test this !!!!!!!!!!! 
// const sequelize = process.env.huzaifaTest
//     ? new Sequelize(process.env.huzaifaTest)
//     : new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PW, {
//         host: 'localhost',
//         dialect: 'mysql',
//         dialectOptions: {
//             decimalNumbers: true,
//         },
//     });
// npm run seed node server.js 

const sequelize = new Sequelize("ecommerce_db", "root", "admin123", {
    host: 'localhost',
    dialect: 'mysql',
    dialectOptions: {
        decimalNumbers: true,
    },
});

module.exports = sequelize;